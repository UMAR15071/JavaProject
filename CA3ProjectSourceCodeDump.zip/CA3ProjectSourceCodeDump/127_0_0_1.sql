-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2023 at 11:27 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--
CREATE DATABASE IF NOT EXISTS `project` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `project`;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_ID` int(20) NOT NULL,
  `First_Name` varchar(15) NOT NULL,
  `Last_Name` varchar(15) NOT NULL,
  `Date_of_Birth` date NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Deleted_Customer` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_ID`, `First_Name`, `Last_Name`, `Date_of_Birth`, `Password`, `Deleted_Customer`) VALUES
(6, 'umar', 'Syed', '0000-00-00', '12345', 1),
(7, 'Tani', 'Shah', '0000-00-00', 'qwerte', 1),
(8, 'zain', 'Muhammad', '2002-12-20', '12345', 0),
(9, 'umar', 'Syed', '2003-12-31', '12345', 0),
(10, 'asad', 'asad', '2003-12-23', 'uiop', 0),
(11, 'John', 'Paul', '2005-12-20', 'asdf', 0);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `Employee_id` int(11) NOT NULL,
  `Emplyee_Name` varchar(15) NOT NULL,
  `Date_of_Birth` date NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Password` varchar(15) NOT NULL,
  `Gender` varchar(25) NOT NULL,
  `DeletedEmployee` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`Employee_id`, `Emplyee_Name`, `Date_of_Birth`, `Email`, `Password`, `Gender`, `DeletedEmployee`) VALUES
(1, 'David', '2020-11-12', 'tuyt@dfgd.com', 'qwerrt', 'Male', 0),
(2, 'ali', '2020-01-20', 'zxc@zxc.com', '12345', 'prefer not to say', 0),
(3, 'qwe', '2020-11-23', 'yui@iop.com', '123456', 'male', 0),
(4, 'ads', '1994-10-25', 'jkl@lkj.com', '123456', 'male', 0),
(5, 'ali', '0000-00-00', 'tyry@hgj', '12345', 'prefer not to say', 1),
(6, 'david', '0000-00-00', '', '123456', 'male', 1),
(7, 'qwe', '2005-12-01', 'asd@asd.com', '123', 'male', 0),
(8, 'john', '2003-12-12', 'asdf@asdf.com', '123445', 'female', 0),
(9, 'Ali', '2005-12-12', 'ajkl@jkl.com', '12345', 'prefer not to say', 0),
(10, 'John', '2020-06-07', 'asd@asd.com', '12345', 'male', 0);

-- --------------------------------------------------------

--
-- Table structure for table `envoice`
--

CREATE TABLE `envoice` (
  `Envoice_ID` int(11) NOT NULL,
  `Customer_ID` int(11) NOT NULL,
  `Product_ID` int(11) NOT NULL,
  `Quantity_Bought` int(11) NOT NULL,
  `Total_Price` decimal(5,0) NOT NULL,
  `Date_of_Purchase` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `envoice`
--

INSERT INTO `envoice` (`Envoice_ID`, `Customer_ID`, `Product_ID`, `Quantity_Bought`, `Total_Price`, `Date_of_Purchase`) VALUES
(1, 6, 9, 3, '18', '2023-03-29'),
(2, 6, 5, 1, '12', '2023-03-29'),
(3, 6, 5, 1, '12', '2023-03-29'),
(4, 6, 10, 1, '50', '2023-03-29'),
(5, 6, 2, 1, '3', '2023-03-29'),
(6, 6, 1, 9, '3', '2023-03-29'),
(7, 6, 10, 2, '100', '2023-03-29'),
(8, 6, 2, 1, '3', '2023-03-29'),
(9, 9, 10, 1, '50', '2023-03-29'),
(10, 8, 9, 1, '6', '2023-03-29'),
(11, 6, 2, 3, '8', '2023-03-29'),
(12, 9, 5, 3, '36', '2023-03-30'),
(13, 8, 7, 5, '50', '2023-03-30'),
(14, 11, 10, 1, '50', '2023-03-30');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `Product_id` int(5) NOT NULL,
  `Product_Name` varchar(30) NOT NULL,
  `Company` varchar(30) NOT NULL,
  `Quantity_in_Stock` int(5) NOT NULL,
  `Unit_Price` varchar(6) NOT NULL,
  `Deleted_Product` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`Product_id`, `Product_Name`, `Company`, `Quantity_in_Stock`, `Unit_Price`, `Deleted_Product`) VALUES
(1, 'Body Lotion', 'Nivea', 0, '1', 1),
(2, 'Face Wash', 'Dove', 15, '2.50', 0),
(3, 'Perfume', 'Nivea', 10, '50.00', 1),
(4, 'Body Wash', 'Dove', 0, '30.00', 1),
(5, 'Body Wash', 'Dove', 9, '12.00', 0),
(6, 'Hand Wash', 'Nirma', 13, '5.00', 0),
(7, 'Hair Gel', 'Lions', 10, '10.0', 0),
(8, 'Hair Gel', 'Lions', 15, '10.0', 1),
(9, 'Shoe Polish', 'Cherry', 24, '5.99', 0),
(10, 'perfume', 'dior', 6, '50.00', 0),
(11, 'Hair Brush', 'Garnier', 20, '5.99', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_ID`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`Employee_id`);

--
-- Indexes for table `envoice`
--
ALTER TABLE `envoice`
  ADD PRIMARY KEY (`Envoice_ID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`Product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `Employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `envoice`
--
ALTER TABLE `envoice`
  MODIFY `Envoice_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `Product_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
